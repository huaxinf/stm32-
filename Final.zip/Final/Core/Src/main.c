/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "gpdma.h"
#include "i2c.h"
#include "memorymap.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "DHT11.h"
#include "CO2.h"
#include <guolv.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
	uint16_t AD_DMA[3];//�������裬Һλ������������ʪ�ȴ��������ݴ�š�0->�������裻1->Һλ��������2->����ʪ��
	uint16_t Count=0;//��ʱ����ļ���ֵ�����ڼ�ʱ��������
	uint8_t MotorReceive[1];//���ڴӴ��ڽ�������
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

//�����жϻص����������ƶ˻�ȡָ�ִ�ж�Ӧ����
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1)
  {
    if (MotorReceive[0] ==1)//��������Ĥ
    {
     
			HAL_GPIO_WritePin(GPIOF,GPIO_PIN_11,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOF,GPIO_PIN_15,GPIO_PIN_RESET);
			__HAL_TIM_SetCompare(&htim5, TIM_CHANNEL_1, 10000);

			HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOE,GPIO_PIN_5,GPIO_PIN_RESET);
			__HAL_TIM_SetCompare(&htim5, TIM_CHANNEL_2, 10000);
		}
		else if(MotorReceive[0] == 2)//���´����Ĥ
		{
			HAL_GPIO_WritePin(GPIOF,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOF,GPIO_PIN_15,GPIO_PIN_SET);
			__HAL_TIM_SetCompare(&htim5, TIM_CHANNEL_1, 10000);

			HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOE,GPIO_PIN_5,GPIO_PIN_SET);
			__HAL_TIM_SetCompare(&htim5, TIM_CHANNEL_2, 10000);
		}
		else if(MotorReceive[0] == 3)//ֹͣ��Ĥ
		{
			HAL_GPIO_WritePin(GPIOF,GPIO_PIN_11,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOF,GPIO_PIN_15,GPIO_PIN_SET);
			__HAL_TIM_SetCompare(&htim5, TIM_CHANNEL_1, 0);

			HAL_GPIO_WritePin(GPIOE,GPIO_PIN_4,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOE,GPIO_PIN_5,GPIO_PIN_SET);
			__HAL_TIM_SetCompare(&htim5, TIM_CHANNEL_2, 0);
		}
		else if(MotorReceive[0] == 4)//��ˮ�ÿ�ʼ��ˮ
		{
			HAL_GPIO_WritePin(shuiben_GPIO_Port,shuiben_Pin,1);
		}
		else if(MotorReceive[0] == 5)//��ˮ��ֹͣ��ˮ
		{
			HAL_GPIO_WritePin(shuiben_GPIO_Port,shuiben_Pin,0);
		}
		else if(MotorReceive[0] == 6)//��ˮ����ʼ��ˮ
		{
			HAL_GPIO_WritePin(choushui_GPIO_Port,choushui_Pin,1);
		}
		else if(MotorReceive[0] == 7)//��ˮ��ֹͣ��ˮ
		{
			HAL_GPIO_WritePin(choushui_GPIO_Port,choushui_Pin,0);
		}
  }
    // ׼��������һ���ֽ�
    HAL_UART_Receive_IT(&huart1, MotorReceive, 1);
}


//AD�жϻص�������ͨ��DMA���ϻ�ȡ�������裬Һλ������������ʪ�ȴ�������ֵ
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)		
{
	HAL_ADC_Stop_DMA(&hadc1);
	HAL_ADC_Start_DMA(&hadc1,(uint32_t *)AD_DMA,3);
}

//ͨ����ʱ����ʱ���֣�1s��һ��
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)//��ʱ
{
	if(htim==&htim3)
	{
		Count++;
	}
}


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_GPDMA1_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_I2C2_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_TIM5_Init();
  /* USER CODE BEGIN 2 */
	HAL_ADC_Stop_DMA(&hadc1);
	HAL_TIM_Base_Start(&htim2);
	HAL_TIM_Base_Start_IT (&htim3);
	HAL_Delay(300);

	CO2_init();//CO2��ʼ������ȴ�16s���Ҳſ���ִ����һ��
	
/**********����ƴ��***************/
	char Lig[] = "Lig";//��ǿ
    char LightNum[6];   
	char Sol[]="Soi";//����
	char SoliNum[6];
	char Tem[]="Tem";//�¶�
	char TemNum[6];
	char Wet[]="Hum";//ʪ��
	char WetNum[6];
	char Wat[]="Wat";//Һλ
	char WaterNum[6];
	char YHT[]="YHT";//CO2
	char CO2Num[7];

  HAL_TIM_Base_Start(&htim5);
  HAL_TIM_PWM_Start(&htim5,TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim5,TIM_CHANNEL_2);
	HAL_UART_Receive_IT(&huart1, MotorReceive, 1);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		
//����ת��
			Water_Select(); 
			Light_change();
			Soil_change();
		
//��ʱ������DHT��AD��������ȡ���ݣ���ֹDHT������
			if(Count%10==0)
			{
				HAL_ADC_Stop_DMA(&hadc1);
				DHT11_get();
			}
			else
			{
				HAL_ADC_Start_DMA(&hadc1,(uint32_t *)AD_DMA,3);
				HAL_Delay(100);	  
			}
			
//CO2��ȡ����
			CO2_get();
			
//��ʼ��20s��ʼ���ն˷�������
			if(Count>=20)
			{
				//����ƴ�ӣ�ÿ����ƴ��һ��
				if(Count%2==0)
				{
					sprintf(LightNum, "%s%d", Lig,Light);
					sprintf(SoliNum, "%s%d", Sol,Soil);
					sprintf(TemNum, "%s%d", Tem,Temperature_integerPart);
					sprintf(WetNum, "%s%d", Wet,Humidity_integerPart);
					sprintf(WaterNum, "%s%d", Wat,yewei);
					sprintf(CO2Num, "%s%d", YHT,CO2/10);
				}
				//���Ͳ��֣�ÿ���뷢��һ�����ݸ��ն�
				if(Count%12==0) 
					HAL_UART_Transmit(&huart1,(uint8_t *)LightNum,sizeof(LightNum),100);
				else if(Count%12==2)
					HAL_UART_Transmit(&huart1,(uint8_t *)SoliNum,sizeof(SoliNum),100);
				else if(Count%12==4)
					HAL_UART_Transmit(&huart1,(uint8_t *)TemNum,sizeof(TemNum),100);
				else if(Count%12==6)
					HAL_UART_Transmit(&huart1,(uint8_t *)WetNum,sizeof(WetNum),100);
				else if(Count%12==8)
					HAL_UART_Transmit(&huart1,(uint8_t *)WaterNum,sizeof(WaterNum),100);
				else if(Count%12==10)
					HAL_UART_Transmit(&huart1,(uint8_t *)CO2Num,sizeof(CO2Num),100);		
			}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLL1_SOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 18;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1_VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1_VCORANGE_WIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_PCLK3;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
