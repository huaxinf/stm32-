#ifndef __GUOLV_H_
#define __GUOLV_H_

#include "main.h"
#include "usart.h"
#include "stdio.h"
#include "DHT11.h"
#include "CO2.h"


extern uint16_t yewei;
extern uint16_t Light;
extern uint16_t Soil;

void Water_Select();
void Light_change();
void Soil_change();


#endif