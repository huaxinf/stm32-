#ifndef _DHT11_H
#define _DHT11_H

#include "stm32h5xx_hal.h"
#include "tim.h"

//#define DHT11_PORT GPIOA
//#define DHT11_PIN GPIO_PIN_1

extern uint8_t Humi_H, Humi_L, Temp_H, Temp_L;
extern uint8_t Temperature_integerPart;
extern uint8_t Humidity_integerPart;
extern uint8_t Presence;


void delay(uint16_t us);

void Set_Pin_Output(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);

void Set_Pin_Input(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);

void DHT11_Start(void);

uint8_t DHT11_Check_Response(void);

uint8_t DHT11_Read(void);

void DHT11_get();

#endif

